# cryptotrader-starterbot-javascript

Javascript starterbot for the Crypto Trader game on Riddles.io

Github repo: https://github.com/riddlesio/cryptotrader-starterbot-javascript
